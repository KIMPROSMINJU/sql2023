package bookTest;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Booklist4 {
//	연결하기 위해 필요한 정보(url, user, pwd)
	String URL = "jdbc:oracle:thin:@localhost:1521:xe";
	String USER = "c##madang";
	String PWD = "madang";
	
	Connection con;
	
	public Booklist4() {
//		JDBC Driver Memory에 Load한다.
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("드라이버 로드 성공");
			
//		Connection 객체 생성
			con = DriverManager.getConnection(URL, USER, PWD);
			System.out.println("DB 연결 성공");
		} catch (ClassNotFoundException e) {
			e.printStackTrace(); 
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void runSQL() {
		String sql = "select * from book";
		try {
//			Connection 객체를 사용해서 문장객체를 생성 및 반환
			Statement stmt = con.createStatement();
//			Statement 객체를 사용해서 SQL문을 실행한 후 ResultSet 집합 객체 반환
			ResultSet rs = stmt.executeQuery(sql);
//			반복문을 사용해서 ResultSet 객체의 행 개수 만큼 데이터를 가져와서 콘솔에 출력
//			next()는 데이터행을 접근할 수 있는 커서를 다음 행으로 이동시키는 기능을 함.
//			실제 cursor가 가리키는 데이터행이 존재하면 true를 반환, 데이터행이 존재하지 않으면 false를 반환
			while(rs.next()) {
				System.out.printf("\t%3d", rs.getInt("bookid"));
				System.out.printf("\t%20s", rs.getString("bookname"));
				System.out.printf("\t\t%8s", rs.getString("publisher"));
				System.out.printf("\t%2d\n", rs.getInt("bookid"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void searchSQL(String name, String menu) {
		String sql = "select " + menu + " from book b, customer c, orders o where b.bookid = o.bookid and o.custid = c.custid and " + menu + " like '%" + name + "%'";
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			System.out.println("\n[출력결과]");
			while(rs.next()) {
				System.out.printf("%20s\n", rs.getString(menu.substring(2)));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		Booklist4 bList = new Booklist4();
		Scanner scan = new Scanner(System.in);
		bList.runSQL();
		while (true) {
			System.out.print("[검색 메뉴]\n1. 도서명\n2. 고객명\n3. 종료\n검색 메뉴를 선택하세요 : ");
			int answer = scan.nextInt();
			switch (answer) {
			case 1:
				System.out.print("도서명의 검색어를 입력하세요 : ");
				String ans = scan.next();
				bList.searchSQL(ans, "b.bookname");
				break;
				
			case 2:
				System.out.print("고객명의 검색어를 입력하세요 : ");
				ans = scan.next();
				bList.searchSQL(ans, "c.name");
				break;
				
			default:
					break;
					
			}
			if (answer == 3) {
				System.out.println("종료합니다.");
				scan.close();
				try {
					bList.con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			}
		}
	}

}